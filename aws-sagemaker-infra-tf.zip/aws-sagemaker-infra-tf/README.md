# aws-sagemaker-infra-tf
This repo to hold AWS SageMaker infrastructure writtent in HCL
